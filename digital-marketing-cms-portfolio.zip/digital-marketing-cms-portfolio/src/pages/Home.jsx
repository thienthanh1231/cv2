export default function Home(){
  return(
    <div className="min-h-screen bg-black text-white">
      <header className="fixed top-0 w-full backdrop-blur-xl border-b border-white/10 bg-black/40">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between">
          <h1 className="text-2xl font-bold">Nova Agency</h1>
          <a href="/admin" className="px-5 py-2 bg-cyan-400 text-black rounded-xl">
            Admin Login
          </a>
        </div>
      </header>

      <section className="min-h-screen flex items-center justify-center text-center px-6">
        <div>
          <p className="uppercase tracking-[0.4em] text-cyan-400 mb-6">
            Premium Digital Marketing Studio
          </p>

          <h2 className="text-6xl md:text-8xl font-black">
            Elevate Your Brand
          </h2>

          <p className="mt-8 max-w-2xl text-gray-400 mx-auto">
            Luxury digital marketing experiences with editable CMS dashboard.
          </p>
        </div>
      </section>
    </div>
  )
}
