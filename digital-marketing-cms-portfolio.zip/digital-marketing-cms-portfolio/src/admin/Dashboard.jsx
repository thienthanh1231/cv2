import { useState } from 'react'

export default function Dashboard(){
  const [title,setTitle]=useState('Elevate Your Brand')
  const [description,setDescription]=useState(
    'Luxury digital marketing experiences.'
  )

  return(
    <div className="min-h-screen bg-[#050505] text-white">
      <div className="flex">
        <aside className="w-72 min-h-screen border-r border-white/10 p-6 bg-black/40">
          <h1 className="text-3xl font-black mb-10">CMS Dashboard</h1>

          <div className="space-y-4 text-gray-300">
            <div>Hero Section</div>
            <div>Projects</div>
            <div>Services</div>
            <div>Blog</div>
            <div>Testimonials</div>
            <div>Contact</div>
          </div>
        </aside>

        <main className="flex-1 p-10">
          <h2 className="text-5xl font-black mb-10">
            Website Content Editor
          </h2>

          <div className="grid gap-8 max-w-3xl">
            <div className="bg-white/5 border border-white/10 rounded-3xl p-8">
              <label className="block mb-3 text-gray-400">
                Hero Title
              </label>

              <input
                value={title}
                onChange={(e)=>setTitle(e.target.value)}
                className="w-full px-4 py-4 rounded-xl bg-black border border-white/10"
              />
            </div>

            <div className="bg-white/5 border border-white/10 rounded-3xl p-8">
              <label className="block mb-3 text-gray-400">
                Hero Description
              </label>

              <textarea
                rows="5"
                value={description}
                onChange={(e)=>setDescription(e.target.value)}
                className="w-full px-4 py-4 rounded-xl bg-black border border-white/10"
              />
            </div>

            <div className="bg-white/5 border border-white/10 rounded-3xl p-8">
              <label className="block mb-3 text-gray-400">
                Upload Banner Image
              </label>

              <input type="file" className="w-full" />
            </div>

            <button className="px-8 py-4 rounded-2xl bg-cyan-400 text-black font-bold w-fit">
              Save Changes
            </button>
          </div>

          <div className="mt-20">
            <h3 className="text-3xl font-bold mb-6">
              Live Preview
            </h3>

            <div className="rounded-3xl border border-white/10 bg-white/5 p-10">
              <h1 className="text-6xl font-black">
                {title}
              </h1>

              <p className="mt-6 text-gray-400 max-w-2xl">
                {description}
              </p>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
