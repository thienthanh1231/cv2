import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

export default function Login(){
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const navigate = useNavigate()

  const handleLogin=(e)=>{
    e.preventDefault()

    if(email==='admin@nova.com' && password==='123456'){
      localStorage.setItem('admin','true')
      navigate('/dashboard')
    }else{
      alert('Invalid login')
    }
  }

  return(
    <div className="min-h-screen flex items-center justify-center bg-black px-6">
      <form
        onSubmit={handleLogin}
        className="w-full max-w-md bg-white/5 border border-white/10 rounded-3xl p-10 backdrop-blur-xl"
      >
        <h1 className="text-4xl font-bold mb-8 text-center">
          Admin Login
        </h1>

        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e)=>setEmail(e.target.value)}
          className="w-full mb-4 px-4 py-4 rounded-xl bg-black border border-white/10"
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e)=>setPassword(e.target.value)}
          className="w-full mb-6 px-4 py-4 rounded-xl bg-black border border-white/10"
        />

        <button className="w-full py-4 rounded-xl bg-cyan-400 text-black font-bold">
          Login
        </button>
      </form>
    </div>
  )
}
